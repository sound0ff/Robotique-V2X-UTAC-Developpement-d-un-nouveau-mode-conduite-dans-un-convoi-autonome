#define ETSI_ITS_MSGS_MESSAGE_DELTAREFERENCEPOSITION_PLUGIN_CONSTRUCTOR \
    DeltaReferencePosition_() : \
        delta_latitude(LATITUDE_UNAVAILABLE), \
        delta_longitude(LONGITUDE_UNAVAILABLE), \
        delta_altitude(ALTITUDE_UNAVAILABLE) {}
