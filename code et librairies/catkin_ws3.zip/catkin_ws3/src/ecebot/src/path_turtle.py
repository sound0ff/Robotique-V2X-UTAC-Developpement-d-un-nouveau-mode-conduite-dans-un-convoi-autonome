#!/usr/bin/env python
# license removed for brevity

## CODE TRAJECTOIRE / PATH POUR TURTLEBOT3
import sys
import rospy
import numpy as np
from math import atan2, sqrt, pi
from geometry_msgs.msg import Twist, Point
from turtlesim.msg import Pose
from nav_msgs.msg import Odometry
from std_msgs.msg import Float32
from simu_msgs.msg import simu_ECE, simu_DENM

#Definition des variables globales
v=0.0 #vitesse lineaire
omega=0.0 #vitesse angulaire
xp=0.0 #coordonnee du prochain point que le robot doit atteindre  (x)
yp=0.0 #coordonnee du prochain point que le robot doit atteindre (y)
compteur_point=0 #parcours a suivre
compteur_dir=0 #changement de direction
liste_dir = [] #coordonnees du circuit a suivre
err_angle_prec = 0 
err_angle = 0
err_vit_prec = 0
err_vit = 0
green_light = True #etat du feux de signalisation
phase = 0
obst = False
err_traj_x = 0
err_traj_y = 0

#Fonction permettant de creer les points a suivre sur le parcours
def create_path():
    a0= np.arange(88.5,98.1,0.1,dtype=float) #1ere ligne droite selon y
    a1= np.arange(101,152.1,0.1,dtype=float) #2eme ligne droite selon x
    a2= np.arange(152,153.1,0.1,dtype=float) #1ere deviation
    a3= np.arange(98.5,98.72,0.02,dtype=float) #1ere deviation
    a4= np.arange(153,155.1,0.1,dtype=float) #1ligne droit
    a5= np.arange(155,156.1,0.1,dtype=float) #2eme deviation
    a6= np.arange(98.5,98.72,0.02,dtype=float) #1ere deviation
    a7= np.arange(156,201.1,0.1,dtype=float) #retour ligne droite
    a8= np.arange(98.5,128.6,0.1,dtype=float) #3eme ligne droite selon y
    liste_dir.append(a0)
    liste_dir.append(a1)
    liste_dir.append(a2)
    liste_dir.append(a3)
    liste_dir.append(a4)
    liste_dir.append(a5)
    liste_dir.append(a6)
    liste_dir.append(a7)
    liste_dir.append(a8)
 

#Fonction permettant de parcourir tous les points definis par la fonction create_path
def set_references(data):
    global compteur_dir, compteur_point, xp, yp

    #premiere portion atteinte
    if(compteur_point>95 and compteur_dir==0):
        compteur_point=0
        compteur_dir+=1

    #deuxieme portion atteinte
    if(compteur_point>510 and compteur_dir==1):
        compteur_point=0
        compteur_dir+=1

    #premiere deviation
    if(compteur_point>10 and compteur_dir==2):
        compteur_point=0
        compteur_dir+=2

    #ligne droite
    if(compteur_point>20 and compteur_dir==4):
        compteur_point=0
        compteur_dir+=1
   
    #deuxieme deviation
    if(compteur_point>10 and compteur_dir==5):
        compteur_point=0
        compteur_dir+=2

    #deuxieme portion atteinte (suite)
    if(compteur_point>450 and compteur_dir==7):
        compteur_point=0
        compteur_dir+=1
	
    #troisieme portion atteinte
    if(compteur_point>300 and compteur_dir==8):
        compteur_point=0
        compteur_dir+=1

    #1ere ligne droite a0:[101][80->98.5]
    if(compteur_dir==0):
        xp=liste_dir[compteur_dir][compteur_point]+2.5
        yp=liste_dir[compteur_dir][compteur_point] 

    #2eme ligne droite a1:[101->152][98.5]
    if(compteur_dir==1):
        xp=liste_dir[compteur_dir][compteur_point]
       	yp=98.5 

    #1ere deviation a2:[152->152.2][98.5->98.7]
    if(compteur_dir==2):
        xp=liste_dir[compteur_dir][compteur_point]
       	yp=liste_dir[compteur_dir+1][compteur_point]

    #2eme ligne droite a1:[152.2 -> 154.2][98.7]
    if(compteur_dir==4):
        xp=liste_dir[compteur_dir][compteur_point]
       	yp=99 

    #2eme deviation a3:[154.2->154.4][98.7->98.5]
    if(compteur_dir==5):
        xp=liste_dir[compteur_dir][compteur_point]
       	yp=liste_dir[compteur_dir+1][9-compteur_point]
	
    #2eme ligne droite (suite) a4:[154.4->201][98.5]
    if(compteur_dir==7):
        xp=liste_dir[compteur_dir][compteur_point]
       	yp=98.5
        
    #3eme ligne droite a2:[201][98.5->128.5]
    if(compteur_dir==8):
        xp=201
       	yp=liste_dir[compteur_dir][compteur_point]

    return xp, yp

#Fonction - Controleur PD (PID) - Controle de la trajectoire du vehicule
def callback(data):
    global v, omega, xp, yp, compteur_point, err_angle, err_angle_prec,err_vit, err_vit_prec, compteur_dir, err_traj_x, err_traj_y
    
    #Recuperer la position du vehicule
    x=data.pose.pose.position.x 
    y=data.pose.pose.position.y  
    qw=data.pose.pose.orientation.w
    qz = data.pose.pose.orientation.z
    
    #Definition de l'angle de lacet
    theta = atan2(2 * qw * qz, 1 - (2 * qz * qz))
    
    #Recuperer les coordonnees du point a atteindre
    xp, yp = set_references(data) 

    #Definition des gains proportionnels et integrales pour la vitesse angulaire omega
    kp_angle = 1.6
    kd_angle = 1.8

    #Definition des gains proportionnels et integrales pour la vitesse lineraire v
    kp_vit = 1
    kd_vit = 1.4

    vmax=1

    #Angle 
    phi=atan2((yp-y),(xp-x))
    
    #Distance entre la position du vehicule et le point a atteindre
    d = sqrt((xp - x)** 2 + (yp - y)** 2)

    # err_traj_x=xp-x
    err_traj_x=x
    # err_traj_y=yp-y
    err_traj_y=y

    #
    delta= theta - phi     

    #
    err_angle = delta

    #
    if delta>pi:
        delta-=2*pi
    if delta<-pi:
        delta+=2*pi
  
    if(compteur_dir==10): #Si parcours definis termine
	omega = 0
        v = 0

    else: 
        #vitesse angulaire
	omega = -kp_angle * delta + kd_angle * (err_angle - err_angle_prec)
        err_angle_prec = err_angle
        #vitesse lineaire
        if(d<0.5):
            compteur_point += 1 #passer a la prochaine coordonnee a atteindre
        err_vit = d
        if v > vmax:
            v=vmax
        else:
            v = kp_vit * d + kd_vit * (err_vit - err_vit_prec)
        err_vit_prec = err_vit


def callback_ece(data):
    global green_light, phase
    green_light = data.permission
    phase = data.phase

def callback_denm(data):
    global obst
    obst = data.obstacle

def talker():
    global v, omega, compteur_point, compteur_dir, err_traj_x, err_traj_y
    
    rospy.init_node('talker', anonymous=True) #Initialisation du noeud

    ece_msg = rospy.Subscriber('vehicles_simu_ECE', simu_ECE, callback_ece) #reception des information depuis le controleur v2x via message ece 
    denm_msg = rospy.Subscriber('vehicles_simu_DENM', simu_DENM, callback_denm)
    sub = rospy.Subscriber('tb3_0/odom', Odometry, callback) #reception des donnees odometrique du vehicule 1
    pub = rospy.Publisher('tb3_0/cmd_vel', Twist, queue_size=10) #envoi de la position du vehicule 1
    trajectoire_pub_x = rospy.Publisher('erreur_trajectoire_x', Float32, queue_size=10)
    trajectoire_pub_y = rospy.Publisher('erreur_trajectoire_y', Float32, queue_size=10)
    
    rate = rospy.Rate(10) # 10hz - frequence d'iteration de la fonction talker
   
    while not rospy.is_shutdown():
        speed = Twist() #controle sur la vitesse
        if green_light == True: #feux vert ou 
            speed.linear.x=v
            speed.angular.z = omega
        elif green_light == False: #feux rouge et 
            speed.linear.x=0
            speed.angular.z=0
        if (obst == True):
            print("obstacle !")
        pub.publish(speed)
        trajectoire_pub_x.publish(err_traj_x)
        trajectoire_pub_y.publish(err_traj_y) 
        rate.sleep()

if __name__ == '__main__':
    try:
        create_path()
        talker()
    except rospy.ROSInterruptException:
        pass
 
