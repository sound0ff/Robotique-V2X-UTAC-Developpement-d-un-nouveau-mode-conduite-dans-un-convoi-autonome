#include "ros/ros.h"
#include "stdio.h"
#include "std_msgs/String.h"
#include "sensor_msgs/LaserScan.h"
#include "../../devel/include/etsi_msgs/DENM.h"
#include "nav_msgs/Odometry.h"
#include <cmath>
#include <iostream>
#include <sstream>
#include "geometry_msgs/Twist.h"


class laser
{
	private:
	ros::NodeHandle n;
	ros::Subscriber sub_laser;
	ros::Publisher pub_denm_l;

	//uint32_t distance_gauche [50];
	//uint32_t distance_droite[50]

	public:
	laser();
	~laser();

	//GETTERS
	ros::Publisher getpub_denm_l();
	ros::Subscriber getsub_laser();
	ros::NodeHandle getnode();

	//SETTERS
	void setnodehandle(ros::NodeHandle n);
	void setpub_denm_l(ros::Publisher pub_denm_l);
	void setsub_laser(ros::Subscriber sub_laser);

	//METHODS
	uint8_t laser_receive(const sensor_msgs::LaserScan::ConstPtr& msg, uint32_t distance_gauche [50], uint32_t distance_droite[50]);
	uint8_t publish_DENM_msg_l(etsi_msgs::DENM msg);

	//CALL BACK
	static void sub_laser_V_callback(const sensor_msgs::LaserScan::ConstPtr& msg, laser *l);

};
