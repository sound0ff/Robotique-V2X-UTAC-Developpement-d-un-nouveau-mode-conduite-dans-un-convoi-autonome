#include "../include/laser.h"

//CONSTRUCTEURS

laser::laser()
{
	this->sub_laser = this->n.subscribe<sensor_msgs::LaserScan>("tb3_0/scan", 1000,boost::bind(sub_laser_V_callback,_1,this));
	this->pub_denm_l = this->n.advertise<etsi_msgs::DENM>("vehicles_DENM", 1000);
}

//DESTRUCTEURS

laser::~laser(){}


//GETTERS

ros::NodeHandle laser::getnode() { return this->n; }
ros::Publisher laser::getpub_denm_l() { return this->pub_denm_l; }
ros::Subscriber laser::getsub_laser() { return this->sub_laser; }

//SETTERS

void laser::setnodehandle(ros::NodeHandle n) { this->n = n; }
void laser::setpub_denm_l(ros::Publisher pub_denm_l) { this->pub_denm_l = pub_denm_l; }
void laser::setsub_laser(ros::Subscriber sub_laser) {this->sub_laser = sub_laser; }

//CALL BACK

void laser::sub_laser_V_callback(const sensor_msgs::LaserScan::ConstPtr& msg, laser *l)
{
	//ROS_INFO("Message laser reçu !");

	uint32_t distance_gauche [50];
	uint32_t distance_droite[50];

	int flag = 0;
	
	//Partie gauche
	for(int i = 0; i<50; i++) //ANGLE 0 a 50
	{
		if(msg->ranges[i] <= 1.5 && i <= 3) //Profondeur de detection - 2.5 & angle de 0 à 3
		{
			distance_gauche[i] = msg->ranges[i];
			flag = 1;
			std::cout<<"time : "<<msg->header.seq <<"\n";
			std::cout<<"angle : "<<i<< "  dist : "<<msg->ranges[i]<<"\n";
		}
		else if(msg->ranges[i] <= 0.55) //Profondeur de detection - 0.55 & angle de 4 à 50
		{
			distance_gauche[i] = msg->ranges[i];
			flag = 1;
			std::cout<<"time : "<<msg->header.seq <<"\n";
			std::cout<<"angle : "<<i<< "  dist : "<<msg->ranges[i]<<"\n";
		}	
	}
	
	//Partie droite
	for (int j = 310; j <360; j++) // ANGLE 310 a 360
	{
		if(msg->ranges[j] <= 1.5 && j >= 357) //Profondeur de detection - 2.5 & angle de 357 à 360
		{
			distance_droite[j-310] = msg->ranges[j];
			flag = 1;
			std::cout<<"time : "<<msg->header.seq <<"\n";
			std::cout<<"angle : "<<j<< "  dist : "<<msg->ranges[j]<<"\n";
		}

		else if(msg->ranges[j] <= 0.55)//Profondeur de detection - 0.55 & angle 310 à 356
		{
			distance_gauche[j] = msg->ranges[j];
			flag = 1;
			std::cout<<"time : "<<msg->header.seq <<"\n";
			std::cout<<"angle : "<<j<< "  dist : "<<msg->ranges[j]<<"\n";
		}
	}

	if(flag == 1)
	{
		l->laser_receive(msg, distance_gauche, distance_droite);
	}
}


//METHODS
uint8_t laser::publish_DENM_msg_l(etsi_msgs::DENM msg)
{
	this->pub_denm_l.publish(msg);
}

uint8_t laser::laser_receive(const sensor_msgs::LaserScan::ConstPtr& msg, uint32_t distance_gauche [50], uint32_t distance_droite[50])
{
	etsi_msgs::DENM msgDENM;
	ROS_INFO("Obstacle détecté par le laser ! \n");

	msgDENM.has_situation = 1;
	msgDENM.has_location = 1;

	publish_DENM_msg_l(msgDENM);
}


//MAIN
int main(int argc, char **argv)
{
	ros::init(argc, argv, "subscriber_laser");
	ros::Time::init();
  	ros::Rate loop_rate(10);
	
	laser l1 = laser();
	
	while(ros::ok())
	{
		ros::spin();
	}
}

